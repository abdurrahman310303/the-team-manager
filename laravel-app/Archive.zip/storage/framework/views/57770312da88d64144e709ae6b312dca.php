<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Project Details')); ?>

            </h2>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('projects.index')); ?>" class="btn-secondary">
                    Back to Projects
                </a>
                <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn-primary">
                    Edit Project
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="dashboard-card mb-8">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-6">
                        <div>
                            <h3 class="text-2xl font-bold text-primary"><?php echo e($project->name); ?></h3>
                            <p class="text-secondary mt-2"><?php echo e($project->description); ?></p>
                        </div>
                        <span class="status-badge status-<?php echo e(str_replace('_', '-', $project->status)); ?>">
                            <?php echo e(ucfirst(str_replace('_', ' ', $project->status))); ?>

                        </span>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div class="text-center p-4 border border-gray-200 rounded-lg">
                            <div class="text-2xl font-bold text-primary">$<?php echo e(number_format($project->budget, 2)); ?></div>
                            <div class="text-sm text-secondary">Budget</div>
                        </div>
                        <div class="text-center p-4 border border-gray-200 rounded-lg">
                            <div class="text-2xl font-bold text-primary"><?php echo e($project->projectManager->name); ?></div>
                            <div class="text-sm text-secondary">Project Manager</div>
                        </div>
                        <div class="text-center p-4 border border-gray-200 rounded-lg">
                            <div class="text-2xl font-bold text-primary">
                                <?php echo e($project->start_date ? $project->start_date->format('M d, Y') : 'N/A'); ?>

                            </div>
                            <div class="text-sm text-secondary">Start Date</div>
                        </div>
                        <div class="text-center p-4 border border-gray-200 rounded-lg">
                            <div class="text-2xl font-bold text-primary">
                                <?php echo e($project->end_date ? $project->end_date->format('M d, Y') : 'N/A'); ?>

                            </div>
                            <div class="text-sm text-secondary">End Date</div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($project->client): ?>
            <div class="dashboard-card mb-8">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-primary mb-4">Client Information</h3>
                    <div class="flex items-center space-x-4">
                        <div class="h-12 w-12 rounded-full bg-gray-300 flex items-center justify-center">
                            <span class="text-sm font-medium text-gray-700">
                                <?php echo e(substr($project->client->name, 0, 2)); ?>

                            </span>
                        </div>
                        <div>
                            <div class="text-sm font-medium text-primary"><?php echo e($project->client->name); ?></div>
                            <div class="text-sm text-secondary"><?php echo e($project->client->email); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Project Proposals -->
                <div class="dashboard-card">
                    <h3 class="text-lg font-semibold text-primary mb-4">Proposals (<?php echo e($project->proposals->count()); ?>)</h3>
                    <div class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $project->proposals->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                                <div class="text-sm font-medium text-primary"><?php echo e($proposal->title); ?></div>
                                <div class="text-xs text-secondary">$<?php echo e(number_format($proposal->proposed_budget, 2)); ?></div>
                            </div>
                            <span class="status-badge status-<?php echo e(str_replace('_', '-', $proposal->status)); ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $proposal->status))); ?>

                            </span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-secondary py-4">No proposals found</div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Project Leads -->
                <div class="dashboard-card">
                    <h3 class="text-lg font-semibold text-primary mb-4">Leads (<?php echo e($project->leads->count()); ?>)</h3>
                    <div class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $project->leads->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                                <div class="text-sm font-medium text-primary"><?php echo e($lead->company_name); ?></div>
                                <div class="text-xs text-secondary"><?php echo e($lead->contact_person); ?></div>
                            </div>
                            <span class="status-badge status-<?php echo e(str_replace('_', '-', $lead->status)); ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $lead->status))); ?>

                            </span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-secondary py-4">No leads found</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/projects/show.blade.php ENDPATH**/ ?>