<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Record Payment')); ?>

            </h2>
            <a href="<?php echo e(route('payments.index')); ?>" class="btn-secondary">
                Back to Payments
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="dashboard-card">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-primary">Payment Details</h3>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-error mb-4">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('payments.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="project_id" class="form-label">Project (Optional)</label>
                                <select name="project_id" id="project_id" class="form-input">
                                    <option value="">Select a project (if applicable)</option>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>" <?php echo e(old('project_id') == $project->id ? 'selected' : ''); ?>>
                                            <?php echo e($project->name); ?> (<?php echo e(ucfirst(str_replace('_', ' ', $project->status))); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label for="fund_purpose" class="form-label">Fund Purpose *</label>
                                <select name="fund_purpose" id="fund_purpose" required class="form-input">
                                    <option value="">Select fund purpose</option>
                                    <option value="salaries" <?php echo e(old('fund_purpose') == 'salaries' ? 'selected' : ''); ?>>Team Salaries</option>
                                    <option value="upwork_connects" <?php echo e(old('fund_purpose') == 'upwork_connects' ? 'selected' : ''); ?>>Upwork Connects</option>
                                    <option value="project_expenses" <?php echo e(old('fund_purpose') == 'project_expenses' ? 'selected' : ''); ?>>Project Expenses</option>
                                    <option value="office_rent" <?php echo e(old('fund_purpose') == 'office_rent' ? 'selected' : ''); ?>>Office Rent</option>
                                    <option value="equipment" <?php echo e(old('fund_purpose') == 'equipment' ? 'selected' : ''); ?>>Equipment</option>
                                    <option value="marketing" <?php echo e(old('fund_purpose') == 'marketing' ? 'selected' : ''); ?>>Marketing</option>
                                    <option value="other" <?php echo e(old('fund_purpose') == 'other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                            </div>

                            <div>
                                <label for="amount" class="form-label">Amount *</label>
                                <input type="number" name="amount" id="amount" value="<?php echo e(old('amount')); ?>" 
                                    required min="0" step="0.01" class="form-input" 
                                    placeholder="Enter payment amount">
                            </div>

                            <div>
                                <label for="currency" class="form-label">Currency *</label>
                                <select name="currency" id="currency" required class="form-input">
                                    <option value="">Select currency</option>
                                    <option value="USD" <?php echo e(old('currency') == 'USD' ? 'selected' : ''); ?>>USD - US Dollar</option>
                                    <option value="EUR" <?php echo e(old('currency') == 'EUR' ? 'selected' : ''); ?>>EUR - Euro</option>
                                    <option value="GBP" <?php echo e(old('currency') == 'GBP' ? 'selected' : ''); ?>>GBP - British Pound</option>
                                    <option value="CAD" <?php echo e(old('currency') == 'CAD' ? 'selected' : ''); ?>>CAD - Canadian Dollar</option>
                                    <option value="AUD" <?php echo e(old('currency') == 'AUD' ? 'selected' : ''); ?>>AUD - Australian Dollar</option>
                                    <option value="JPY" <?php echo e(old('currency') == 'JPY' ? 'selected' : ''); ?>>JPY - Japanese Yen</option>
                                    <option value="PKR" <?php echo e(old('currency') == 'PKR' ? 'selected' : ''); ?>>PKR - Pakistani Rupee</option>
                                    <option value="INR" <?php echo e(old('currency') == 'INR' ? 'selected' : ''); ?>>INR - Indian Rupee</option>
                                </select>
                            </div>

                            <div>
                                <label for="exchange_rate" class="form-label">Exchange Rate to USD</label>
                                <input type="number" name="exchange_rate" id="exchange_rate" value="<?php echo e(old('exchange_rate')); ?>" 
                                    min="0" step="0.0001" class="form-input" 
                                    placeholder="Enter exchange rate (e.g., 0.85 for EUR)">
                                <p class="text-xs text-gray-500 mt-1">Leave empty if currency is USD or if you don't know the rate</p>
                            </div>

                            <div class="md:col-span-2">
                                <div class="flex items-center">
                                    <input type="checkbox" name="is_project_related" id="is_project_related" value="1" 
                                        <?php echo e(old('is_project_related') ? 'checked' : ''); ?> class="mr-2">
                                    <label for="is_project_related" class="text-sm text-gray-700">This payment is related to a specific project</label>
                                </div>
                            </div>

                            <div>
                                <label for="payment_type" class="form-label">Payment Type *</label>
                                <select name="payment_type" id="payment_type" required class="form-input">
                                    <option value="">Select payment type</option>
                                    <option value="investment" <?php echo e(old('payment_type') == 'investment' ? 'selected' : ''); ?>>Investment</option>
                                    <option value="reimbursement" <?php echo e(old('payment_type') == 'reimbursement' ? 'selected' : ''); ?>>Reimbursement</option>
                                    <option value="profit_share" <?php echo e(old('payment_type') == 'profit_share' ? 'selected' : ''); ?>>Profit Share</option>
                                    <option value="other" <?php echo e(old('payment_type') == 'other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                            </div>

                            <div>
                                <label for="payment_method" class="form-label">Payment Method *</label>
                                <select name="payment_method" id="payment_method" required class="form-input">
                                    <option value="">Select payment method</option>
                                    <option value="bank_transfer" <?php echo e(old('payment_method') == 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                                    <option value="check" <?php echo e(old('payment_method') == 'check' ? 'selected' : ''); ?>>Check</option>
                                    <option value="cash" <?php echo e(old('payment_method') == 'cash' ? 'selected' : ''); ?>>Cash</option>
                                    <option value="other" <?php echo e(old('payment_method') == 'other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                            </div>

                            <div>
                                <label for="status" class="form-label">Status *</label>
                                <select name="status" id="status" required class="form-input">
                                    <option value="">Select status</option>
                                    <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="completed" <?php echo e(old('status') == 'completed' ? 'selected' : ''); ?>>Completed</option>
                                    <option value="failed" <?php echo e(old('status') == 'failed' ? 'selected' : ''); ?>>Failed</option>
                                </select>
                            </div>

                            <div>
                                <label for="payment_date" class="form-label">Payment Date *</label>
                                <input type="date" name="payment_date" id="payment_date" 
                                    value="<?php echo e(old('payment_date', date('Y-m-d'))); ?>" required class="form-input">
                            </div>

                            <div>
                                <label for="reference_number" class="form-label">Reference Number</label>
                                <input type="text" name="reference_number" id="reference_number" 
                                    value="<?php echo e(old('reference_number')); ?>" class="form-input" 
                                    placeholder="Enter reference number">
                            </div>

                            <div class="md:col-span-2">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea name="notes" id="notes" rows="4" 
                                    class="form-input" placeholder="Enter any additional notes"><?php echo e(old('notes')); ?></textarea>
                            </div>
                        </div>

                        <div class="mt-6 flex justify-end space-x-3">
                            <a href="<?php echo e(route('payments.index')); ?>" class="btn-secondary">
                                Cancel
                            </a>
                            <button type="submit" class="btn-primary">
                                Record Payment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/payments/create.blade.php ENDPATH**/ ?>