<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Admin Overview - All Team Details')); ?>

            </h2>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn-secondary">
                    Manage Users
                </a>
                <a href="<?php echo e(route('projects.create')); ?>" class="btn-primary">
                    New Project
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Quick Stats -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="dashboard-stat">
                    <div class="dashboard-stat-value"><?php echo e($stats['total_users']); ?></div>
                    <div class="dashboard-stat-label">Total Users</div>
                </div>
                <div class="dashboard-stat">
                    <div class="dashboard-stat-value"><?php echo e($stats['total_projects']); ?></div>
                    <div class="dashboard-stat-label">Total Projects</div>
                </div>
                <div class="dashboard-stat">
                    <div class="dashboard-stat-value"><?php echo e($stats['total_proposals']); ?></div>
                    <div class="dashboard-stat-label">Total Proposals</div>
                </div>
                <div class="dashboard-stat">
                    <div class="dashboard-stat-value"><?php echo e($stats['total_leads']); ?></div>
                    <div class="dashboard-stat-label">Total Leads</div>
                </div>
            </div>

            <!-- Users by Role -->
            <div class="dashboard-card mb-8">
                <h3 class="text-lg font-semibold text-primary mb-4">Users by Role</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <?php $__currentLoopData = $stats['users_by_role']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center p-4 border border-gray-200 rounded-lg">
                        <div class="text-2xl font-bold text-primary"><?php echo e($count); ?></div>
                        <div class="text-sm text-secondary"><?php echo e(ucfirst(str_replace('_', ' ', $role))); ?></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Projects by Status -->
            <div class="dashboard-card mb-8">
                <h3 class="text-lg font-semibold text-primary mb-4">Projects by Status</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    <?php $__currentLoopData = $stats['projects_by_status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center p-4 border border-gray-200 rounded-lg">
                        <div class="text-2xl font-bold text-primary"><?php echo e($status->count); ?></div>
                        <div class="text-sm text-secondary"><?php echo e(ucfirst(str_replace('_', ' ', $status->status))); ?></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Team Members Table -->
            <div class="dashboard-card mb-8">
                <h3 class="text-lg font-semibold text-primary mb-6">Team Members</h3>
                <div class="table-container">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="table-header">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Email</th>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Role</th>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Projects</th>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Proposals</th>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Leads</th>
                                <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-row">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10">
                                            <div class="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                                                <span class="text-sm font-medium text-gray-700">
                                                    <?php echo e(substr($user->name, 0, 2)); ?>

                                                </span>
                                            </div>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-primary"><?php echo e($user->name); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                    <?php echo e($user->email); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if($user->role): ?>
                                        <span class="status-badge status-<?php echo e($user->role->name); ?>">
                                            <?php echo e($user->role->display_name); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="status-badge" style="background-color: #f3f4f6; color: #6b7280;">
                                            No Role
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                    <?php echo e($user->managedProjects->count()); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                    <?php echo e($user->proposals->count()); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                    <?php echo e($user->leads->count()); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <div class="flex space-x-2">
                                        <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="text-blue-600 hover:text-blue-900">View</a>
                                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="text-green-600 hover:text-green-900">Edit</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Recent Activities -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Recent Projects -->
                <div class="dashboard-card">
                    <h3 class="text-lg font-semibold text-primary mb-4">Recent Projects</h3>
                    <div class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $recent_activities->where('type', 'project')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                                <div class="text-sm font-medium text-primary"><?php echo e($activity['title']); ?></div>
                                <div class="text-xs text-secondary"><?php echo e($activity['description']); ?></div>
                            </div>
                            <div class="text-xs text-muted"><?php echo e($activity['time']); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-secondary py-4">No recent projects</div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Proposals -->
                <div class="dashboard-card">
                    <h3 class="text-lg font-semibold text-primary mb-4">Recent Proposals</h3>
                    <div class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $recent_activities->where('type', 'proposal')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                                <div class="text-sm font-medium text-primary"><?php echo e($activity['title']); ?></div>
                                <div class="text-xs text-secondary"><?php echo e($activity['description']); ?></div>
                            </div>
                            <div class="text-xs text-muted"><?php echo e($activity['time']); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-secondary py-4">No recent proposals</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/admin/overview.blade.php ENDPATH**/ ?>