<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Leads')); ?>

            </h2>
            <?php if(auth()->user()->hasRole('bd') || auth()->user()->hasRole('admin')): ?>
                <a href="<?php echo e(route('leads.create')); ?>" class="btn-primary">
                    <i class="fas fa-plus mr-2"></i>
                    Create New Lead
                </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="dashboard-card">
                <div class="p-6">
                    <?php if(session('success')): ?>
                        <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-primary">All Leads</h3>
                        <div class="text-sm text-secondary">
                            Total: <?php echo e($leads->total()); ?> leads
                        </div>
                    </div>

                    <div class="table-container">
                        <table class="w-full divide-y divide-gray-200">
                            <thead class="table-header">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider w-1/5">Company</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden md:table-cell w-1/6">Platform</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider w-1/6">Bidding Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden lg:table-cell w-1/6">Priority</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden lg:table-cell w-1/6">Value</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden md:table-cell w-1/6">Assigned To</th>
                                    <th class="px-4 py-3 text-center text-xs font-medium uppercase tracking-wider w-24">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="table-row hover:bg-gray-50">
                                    <td class="px-4 py-4 text-sm font-medium text-primary">
                                        <div class="flex flex-col">
                                            <span class="font-semibold"><?php echo e($lead->company_name); ?></span>
                                            <span class="text-xs text-gray-500 md:hidden"><?php echo e(ucfirst($lead->bidding_platform)); ?></span>
                                            <span class="text-xs text-gray-500 lg:hidden">Priority: <?php echo e($lead->bidding_priority); ?>/5</span>
                                        </div>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden md:table-cell">
                                        <div class="flex items-center">
                                            <?php if($lead->bidding_platform === 'upwork'): ?>
                                                <i class="fab fa-upwork mr-1 text-orange-500"></i>
                                            <?php elseif($lead->bidding_platform === 'linkedin'): ?>
                                                <i class="fab fa-linkedin mr-1 text-blue-600"></i>
                                            <?php else: ?>
                                                <i class="fas fa-globe mr-1 text-gray-500"></i>
                                            <?php endif; ?>
                                            <span class="font-medium"><?php echo e(ucfirst($lead->bidding_platform)); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-4 py-4">
                                        <span class="status-badge status-<?php echo e(str_replace('_', '-', $lead->bidding_status)); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $lead->bidding_status))); ?>

                                        </span>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden lg:table-cell">
                                        <div class="flex items-center">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star <?php echo e($i <= $lead->bidding_priority ? 'text-yellow-400' : 'text-gray-300'); ?> text-xs"></i>
                                            <?php endfor; ?>
                                            <span class="ml-1 text-xs"><?php echo e($lead->bidding_priority); ?>/5</span>
                                        </div>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden lg:table-cell">
                                        <?php if($lead->estimated_value): ?>
                                            <span class="font-semibold text-green-600">$<?php echo e(number_format($lead->estimated_value, 2)); ?></span>
                                        <?php else: ?>
                                            <span class="text-gray-400">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden md:table-cell">
                                        <?php echo e($lead->assignedTo->name); ?>

                                    </td>
                                    <td class="px-4 py-4 text-center">
                                        <div class="flex flex-col gap-1">
                                            <a href="<?php echo e(route('leads.show', $lead)); ?>" class="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded hover:bg-blue-200 text-center transition-colors">View</a>
                                            <?php if(auth()->user()->hasRole('bd') || auth()->user()->hasRole('admin')): ?>
                                                <?php if(auth()->user()->hasRole('admin') || $lead->assigned_to === auth()->id()): ?>
                                                    <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="inline-block px-2 py-1 text-xs bg-green-100 text-green-800 rounded hover:bg-green-200 text-center transition-colors">Edit</a>
                                                    <form action="<?php echo e(route('leads.destroy', $lead)); ?>" method="POST" class="inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="w-full px-2 py-1 text-xs bg-red-100 text-red-800 rounded hover:bg-red-200 transition-colors" onclick="return confirm('Are you sure?')">Delete</button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-4 text-center text-sm text-secondary">No leads found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($leads->hasPages()): ?>
                        <div class="mt-6">
                            <?php echo e($leads->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/leads/index.blade.php ENDPATH**/ ?>