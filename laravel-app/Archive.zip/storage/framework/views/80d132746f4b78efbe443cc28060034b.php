<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Submit Daily Report')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="dashboard-card">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-primary">Daily Work Report</h3>
                        <a href="<?php echo e(route('daily-reports.index')); ?>" class="btn-secondary">
                            Back to Reports
                        </a>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-error mb-4">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('daily-reports.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="project_id" class="form-label">Project (Optional)</label>
                                <select name="project_id" id="project_id" class="form-input">
                                    <option value="">Select a project</option>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>" <?php echo e(old('project_id') == $project->id ? 'selected' : ''); ?>>
                                            <?php echo e($project->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label for="report_date" class="form-label">Report Date</label>
                                <input type="date" name="report_date" id="report_date" value="<?php echo e(old('report_date', date('Y-m-d'))); ?>" required
                                    class="form-input <?php $__errorArgs = ['report_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['report_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="md:col-span-2">
                                <label for="work_completed" class="form-label">Work Completed Today *</label>
                                <textarea name="work_completed" id="work_completed" rows="4" required
                                    class="form-input"
                                    placeholder="Describe what you accomplished today..."><?php echo e(old('work_completed')); ?></textarea>
                            </div>

                            <div>
                                <label for="challenges_faced" class="form-label">Challenges Faced</label>
                                <textarea name="challenges_faced" id="challenges_faced" rows="3"
                                    class="form-input"
                                    placeholder="Any challenges or issues you encountered..."><?php echo e(old('challenges_faced')); ?></textarea>
                            </div>

                            <div>
                                <label for="next_plans" class="form-label">Next Plans</label>
                                <textarea name="next_plans" id="next_plans" rows="3"
                                    class="form-input"
                                    placeholder="What do you plan to work on next..."><?php echo e(old('next_plans')); ?></textarea>
                            </div>

                            <div>
                                <label for="hours_worked" class="form-label">Hours Worked *</label>
                                <input type="number" name="hours_worked" id="hours_worked" value="<?php echo e(old('hours_worked')); ?>" min="0" max="24" required
                                    class="form-input">
                            </div>

                            <?php if($reportType === 'bd'): ?>
                            <div>
                                <label for="leads_generated" class="form-label">Leads Generated</label>
                                <input type="number" name="leads_generated" id="leads_generated" value="<?php echo e(old('leads_generated', 0)); ?>" min="0"
                                    class="form-input">
                            </div>

                            <div>
                                <label for="proposals_submitted" class="form-label">Proposals Submitted</label>
                                <input type="number" name="proposals_submitted" id="proposals_submitted" value="<?php echo e(old('proposals_submitted', 0)); ?>" min="0"
                                    class="form-input">
                            </div>

                            <div>
                                <label for="projects_locked" class="form-label">Projects Locked</label>
                                <input type="number" name="projects_locked" id="projects_locked" value="<?php echo e(old('projects_locked', 0)); ?>" min="0"
                                    class="form-input">
                            </div>

                            <div>
                                <label for="revenue_generated" class="form-label">Revenue Generated ($)</label>
                                <input type="number" name="revenue_generated" id="revenue_generated" value="<?php echo e(old('revenue_generated', 0)); ?>" min="0" step="0.01"
                                    class="form-input">
                            </div>
                            <?php endif; ?>

                            <div class="md:col-span-2">
                                <label for="notes" class="form-label">Additional Notes</label>
                                <textarea name="notes" id="notes" rows="3"
                                    class="form-input"
                                    placeholder="Any additional notes or comments..."><?php echo e(old('notes')); ?></textarea>
                            </div>
                        </div>

                        <div class="mt-6 flex justify-end space-x-3">
                            <a href="<?php echo e(route('daily-reports.index')); ?>" class="btn-secondary">
                                Cancel
                            </a>
                            <button type="submit" class="btn-primary">
                                Submit Report
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/daily-reports/create.blade.php ENDPATH**/ ?>