<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('User Details: ' . $user->name)); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-gray-900">User Information</h3>
                        <div class="flex space-x-3">
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                                Back to Users
                            </a>
                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Edit User
                            </a>
                        </div>
                    </div>

                    <!-- User Basic Info -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="text-sm font-medium text-gray-500 mb-2">Basic Information</h4>
                            <div class="space-y-2">
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Name:</span>
                                    <span class="text-sm text-gray-900 ml-2"><?php echo e($user->name); ?></span>
                                </div>
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Email:</span>
                                    <span class="text-sm text-gray-900 ml-2"><?php echo e($user->email); ?></span>
                                </div>
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Role:</span>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php if($user->role && $user->role->name == 'admin'): ?> bg-red-100 text-red-800
                                        <?php elseif($user->role && $user->role->name == 'developer'): ?> bg-blue-100 text-blue-800
                                        <?php elseif($user->role && $user->role->name == 'investor'): ?> bg-green-100 text-green-800
                                        <?php elseif($user->role && $user->role->name == 'bd'): ?> bg-purple-100 text-purple-800
                                        <?php else: ?> bg-gray-100 text-gray-800
                                        <?php endif; ?> ml-2">
                                        <?php echo e($user->role ? $user->role->display_name : 'No Role'); ?>

                                    </span>
                                </div>
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Member Since:</span>
                                    <span class="text-sm text-gray-900 ml-2"><?php echo e($user->created_at->format('M d, Y')); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="text-sm font-medium text-gray-500 mb-2">Activity Summary</h4>
                            <div class="space-y-2">
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Projects Managed:</span>
                                    <span class="text-sm text-gray-900 ml-2"><?php echo e($user->managedProjects->count()); ?></span>
                                </div>
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Proposals Submitted:</span>
                                    <span class="text-sm text-gray-900 ml-2"><?php echo e($user->proposals->count()); ?></span>
                                </div>
                                <div>
                                    <span class="text-sm font-medium text-gray-700">Leads Assigned:</span>
                                    <span class="text-sm text-gray-900 ml-2"><?php echo e($user->leads->count()); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- User's Projects -->
                    <div class="mb-8">
                        <h4 class="text-lg font-medium text-gray-900 mb-4">Managed Projects</h4>
                        <?php if($user->managedProjects->count() > 0): ?>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Project Name</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Budget</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $user->managedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                <a href="<?php echo e(route('projects.show', $project)); ?>" class="text-blue-600 hover:text-blue-900">
                                                    <?php echo e($project->name); ?>

                                                </a>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php if($project->status == 'in_progress'): ?> bg-green-100 text-green-800
                                                    <?php elseif($project->status == 'completed'): ?> bg-blue-100 text-blue-800
                                                    <?php elseif($project->status == 'on_hold'): ?> bg-yellow-100 text-yellow-800
                                                    <?php else: ?> bg-gray-100 text-gray-800
                                                    <?php endif; ?>">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $project->status))); ?>

                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                $<?php echo e(number_format($project->budget, 2)); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($project->client->name ?? 'N/A'); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-sm text-gray-500">No projects managed by this user.</p>
                        <?php endif; ?>
                    </div>

                    <!-- User's Proposals -->
                    <div class="mb-8">
                        <h4 class="text-lg font-medium text-gray-900 mb-4">Submitted Proposals</h4>
                        <?php if($user->proposals->count() > 0): ?>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Budget</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Project</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $user->proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                <a href="<?php echo e(route('proposals.show', $proposal)); ?>" class="text-blue-600 hover:text-blue-900">
                                                    <?php echo e($proposal->title); ?>

                                                </a>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php if($proposal->status == 'accepted'): ?> bg-green-100 text-green-800
                                                    <?php elseif($proposal->status == 'rejected'): ?> bg-red-100 text-red-800
                                                    <?php elseif($proposal->status == 'under_review'): ?> bg-yellow-100 text-yellow-800
                                                    <?php else: ?> bg-gray-100 text-gray-800
                                                    <?php endif; ?>">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $proposal->status))); ?>

                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                $<?php echo e(number_format($proposal->proposed_budget, 2)); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($proposal->project->name); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-sm text-gray-500">No proposals submitted by this user.</p>
                        <?php endif; ?>
                    </div>

                    <!-- User's Leads -->
                    <div>
                        <h4 class="text-lg font-medium text-gray-900 mb-4">Assigned Leads</h4>
                        <?php if($user->leads->count() > 0): ?>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $user->leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                <a href="<?php echo e(route('leads.show', $lead)); ?>" class="text-blue-600 hover:text-blue-900">
                                                    <?php echo e($lead->company_name); ?>

                                                </a>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($lead->contact_person); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php if($lead->status == 'new'): ?> bg-blue-100 text-blue-800
                                                    <?php elseif($lead->status == 'qualified'): ?> bg-green-100 text-green-800
                                                    <?php elseif($lead->status == 'closed_won'): ?> bg-purple-100 text-purple-800
                                                    <?php elseif($lead->status == 'closed_lost'): ?> bg-red-100 text-red-800
                                                    <?php else: ?> bg-gray-100 text-gray-800
                                                    <?php endif; ?>">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $lead->status))); ?>

                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                $<?php echo e(number_format($lead->estimated_value, 2)); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-sm text-gray-500">No leads assigned to this user.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/admin/users/show.blade.php ENDPATH**/ ?>