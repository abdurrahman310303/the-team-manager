<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Create New Lead')); ?>

            </h2>
            <a href="<?php echo e(route('leads.index')); ?>" class="btn-secondary">
                <i class="fas fa-arrow-left mr-2"></i>
                Back to Leads
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if($errors->any()): ?>
                <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('leads.store')); ?>" method="POST" class="space-y-8">
                <?php echo csrf_field(); ?>
                
                <!-- Platform Selection -->
                <div class="dashboard-card">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-primary mb-4 flex items-center">
                            <i class="fas fa-bullseye mr-2"></i>
                            Platform & Bidding Information
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label for="bidding_platform" class="form-label">Platform *</label>
                                <select name="bidding_platform" id="bidding_platform" required class="form-input" onchange="togglePlatformFields()">
                                    <option value="">Select platform</option>
                                    <option value="upwork" <?php echo e(old('bidding_platform') == 'upwork' ? 'selected' : ''); ?>>Upwork</option>
                                    <option value="linkedin" <?php echo e(old('bidding_platform') == 'linkedin' ? 'selected' : ''); ?>>LinkedIn</option>
                                    <option value="direct" <?php echo e(old('bidding_platform') == 'direct' ? 'selected' : ''); ?>>Direct Contact</option>
                                    <option value="referral" <?php echo e(old('bidding_platform') == 'referral' ? 'selected' : ''); ?>>Referral</option>
                                    <option value="other" <?php echo e(old('bidding_platform') == 'other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                                <?php $__errorArgs = ['bidding_platform'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="bidding_status" class="form-label">Bidding Status *</label>
                                <select name="bidding_status" id="bidding_status" required class="form-input">
                                    <option value="">Select status</option>
                                    <option value="researching" <?php echo e(old('bidding_status') == 'researching' ? 'selected' : ''); ?>>Researching</option>
                                    <option value="ready_to_bid" <?php echo e(old('bidding_status') == 'ready_to_bid' ? 'selected' : ''); ?>>Ready to Bid</option>
                                    <option value="bid_sent" <?php echo e(old('bidding_status') == 'bid_sent' ? 'selected' : ''); ?>>Bid Sent</option>
                                    <option value="interviewing" <?php echo e(old('bidding_status') == 'interviewing' ? 'selected' : ''); ?>>Interviewing</option>
                                    <option value="negotiating" <?php echo e(old('bidding_status') == 'negotiating' ? 'selected' : ''); ?>>Negotiating</option>
                                    <option value="won" <?php echo e(old('bidding_status') == 'won' ? 'selected' : ''); ?>>Won</option>
                                    <option value="lost" <?php echo e(old('bidding_status') == 'lost' ? 'selected' : ''); ?>>Lost</option>
                                    <option value="withdrawn" <?php echo e(old('bidding_status') == 'withdrawn' ? 'selected' : ''); ?>>Withdrawn</option>
                                </select>
                                <?php $__errorArgs = ['bidding_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="bidding_priority" class="form-label">Priority (1-5)</label>
                                <select name="bidding_priority" id="bidding_priority" class="form-input">
                                    <option value="1" <?php echo e(old('bidding_priority') == '1' ? 'selected' : ''); ?>>1 - Low</option>
                                    <option value="2" <?php echo e(old('bidding_priority') == '2' ? 'selected' : ''); ?>>2 - Below Average</option>
                                    <option value="3" <?php echo e(old('bidding_priority') == '3' ? 'selected' : ''); ?>>3 - Average</option>
                                    <option value="4" <?php echo e(old('bidding_priority') == '4' ? 'selected' : ''); ?>>4 - High</option>
                                    <option value="5" <?php echo e(old('bidding_priority') == '5' ? 'selected' : ''); ?>>5 - Critical</option>
                                </select>
                                <?php $__errorArgs = ['bidding_priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Basic Lead Information -->
                <div class="dashboard-card">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-primary mb-4 flex items-center">
                            <i class="fas fa-building mr-2"></i>
                            Basic Lead Information
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div>
                                <label for="company_name" class="form-label">Company Name *</label>
                                <input type="text" name="company_name" id="company_name" value="<?php echo e(old('company_name')); ?>" 
                                    required class="form-input" placeholder="Enter company name">
                                <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="contact_person" class="form-label">Contact Person *</label>
                                <input type="text" name="contact_person" id="contact_person" value="<?php echo e(old('contact_person')); ?>" 
                                    required class="form-input" placeholder="Enter contact person name">
                                <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" 
                                    required class="form-input" placeholder="Enter email address">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" name="phone" id="phone" value="<?php echo e(old('phone')); ?>" 
                                    class="form-input" placeholder="Enter phone number">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="estimated_value" class="form-label">Estimated Value ($)</label>
                                <input type="number" name="estimated_value" id="estimated_value" value="<?php echo e(old('estimated_value')); ?>" 
                                    min="0" step="0.01" class="form-input" placeholder="Enter estimated value">
                                <?php $__errorArgs = ['estimated_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="last_contact_date" class="form-label">Last Contact Date</label>
                                <input type="date" name="last_contact_date" id="last_contact_date" value="<?php echo e(old('last_contact_date')); ?>" 
                                    class="form-input">
                                <?php $__errorArgs = ['last_contact_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mt-4">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" rows="3" class="form-input" 
                                placeholder="Enter lead description"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Upwork Specific Fields -->
                <div id="upwork-fields" class="dashboard-card" style="display: none;">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-primary mb-4 flex items-center">
                            <i class="fab fa-upwork mr-2"></i>
                            Upwork Job Details
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div>
                                <label for="upwork_job_id" class="form-label">Job ID</label>
                                <input type="text" name="upwork_job_id" id="upwork_job_id" value="<?php echo e(old('upwork_job_id')); ?>" 
                                    class="form-input" placeholder="e.g., ~1234567890abcdef">
                                <?php $__errorArgs = ['upwork_job_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_job_url" class="form-label">Job URL</label>
                                <input type="url" name="upwork_job_url" id="upwork_job_url" value="<?php echo e(old('upwork_job_url')); ?>" 
                                    class="form-input" placeholder="https://upwork.com/jobs/...">
                                <?php $__errorArgs = ['upwork_job_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_job_type" class="form-label">Job Type</label>
                                <select name="upwork_job_type" id="upwork_job_type" class="form-input">
                                    <option value="">Select type</option>
                                    <option value="hourly" <?php echo e(old('upwork_job_type') == 'hourly' ? 'selected' : ''); ?>>Hourly</option>
                                    <option value="fixed_price" <?php echo e(old('upwork_job_type') == 'fixed_price' ? 'selected' : ''); ?>>Fixed Price</option>
                                    <option value="milestone" <?php echo e(old('upwork_job_type') == 'milestone' ? 'selected' : ''); ?>>Milestone</option>
                                </select>
                                <?php $__errorArgs = ['upwork_job_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_budget_min" class="form-label">Min Budget ($)</label>
                                <input type="number" name="upwork_budget_min" id="upwork_budget_min" value="<?php echo e(old('upwork_budget_min')); ?>" 
                                    min="0" step="0.01" class="form-input" placeholder="Minimum budget">
                                <?php $__errorArgs = ['upwork_budget_min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_budget_max" class="form-label">Max Budget ($)</label>
                                <input type="number" name="upwork_budget_max" id="upwork_budget_max" value="<?php echo e(old('upwork_budget_max')); ?>" 
                                    min="0" step="0.01" class="form-input" placeholder="Maximum budget">
                                <?php $__errorArgs = ['upwork_budget_max'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_connects_required" class="form-label">Connects Required</label>
                                <input type="number" name="upwork_connects_required" id="upwork_connects_required" value="<?php echo e(old('upwork_connects_required')); ?>" 
                                    min="0" class="form-input" placeholder="Number of connects">
                                <?php $__errorArgs = ['upwork_connects_required'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_client_rating" class="form-label">Client Rating</label>
                                <select name="upwork_client_rating" id="upwork_client_rating" class="form-input">
                                    <option value="">Select rating</option>
                                    <option value="excellent" <?php echo e(old('upwork_client_rating') == 'excellent' ? 'selected' : ''); ?>>Excellent (4.5+)</option>
                                    <option value="good" <?php echo e(old('upwork_client_rating') == 'good' ? 'selected' : ''); ?>>Good (4.0-4.4)</option>
                                    <option value="average" <?php echo e(old('upwork_client_rating') == 'average' ? 'selected' : ''); ?>>Average (3.5-3.9)</option>
                                    <option value="poor" <?php echo e(old('upwork_client_rating') == 'poor' ? 'selected' : ''); ?>>Poor (<3.5)</option>
                                    <option value="new" <?php echo e(old('upwork_client_rating') == 'new' ? 'selected' : ''); ?>>New Client</option>
                                </select>
                                <?php $__errorArgs = ['upwork_client_rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_experience_level" class="form-label">Experience Level</label>
                                <select name="upwork_experience_level" id="upwork_experience_level" class="form-input">
                                    <option value="">Select level</option>
                                    <option value="entry" <?php echo e(old('upwork_experience_level') == 'entry' ? 'selected' : ''); ?>>Entry Level</option>
                                    <option value="intermediate" <?php echo e(old('upwork_experience_level') == 'intermediate' ? 'selected' : ''); ?>>Intermediate</option>
                                    <option value="expert" <?php echo e(old('upwork_experience_level') == 'expert' ? 'selected' : ''); ?>>Expert</option>
                                </select>
                                <?php $__errorArgs = ['upwork_experience_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_job_duration" class="form-label">Duration (days)</label>
                                <input type="number" name="upwork_job_duration" id="upwork_job_duration" value="<?php echo e(old('upwork_job_duration')); ?>" 
                                    min="1" class="form-input" placeholder="Project duration">
                                <?php $__errorArgs = ['upwork_job_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mt-4">
                            <label for="upwork_job_description" class="form-label">Job Description</label>
                            <textarea name="upwork_job_description" id="upwork_job_description" rows="4" class="form-input" 
                                placeholder="Copy the job description from Upwork"><?php echo e(old('upwork_job_description')); ?></textarea>
                            <?php $__errorArgs = ['upwork_job_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-4">
                            <label for="upwork_skills_required" class="form-label">Skills Required</label>
                            <textarea name="upwork_skills_required" id="upwork_skills_required" rows="2" class="form-input" 
                                placeholder="List required skills (comma separated)"><?php echo e(old('upwork_skills_required')); ?></textarea>
                            <?php $__errorArgs = ['upwork_skills_required'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- LinkedIn Specific Fields -->
                <div id="linkedin-fields" class="dashboard-card" style="display: none;">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-primary mb-4 flex items-center">
                            <i class="fab fa-linkedin mr-2"></i>
                            LinkedIn Connection Details
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="linkedin_company_url" class="form-label">Company LinkedIn URL</label>
                                <input type="url" name="linkedin_company_url" id="linkedin_company_url" value="<?php echo e(old('linkedin_company_url')); ?>" 
                                    class="form-input" placeholder="https://linkedin.com/company/...">
                                <?php $__errorArgs = ['linkedin_company_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="linkedin_contact_url" class="form-label">Contact LinkedIn URL</label>
                                <input type="url" name="linkedin_contact_url" id="linkedin_contact_url" value="<?php echo e(old('linkedin_contact_url')); ?>" 
                                    class="form-input" placeholder="https://linkedin.com/in/...">
                                <?php $__errorArgs = ['linkedin_contact_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mt-4">
                            <label for="linkedin_connection_message" class="form-label">Connection Message</label>
                            <textarea name="linkedin_connection_message" id="linkedin_connection_message" rows="3" class="form-input" 
                                placeholder="Your LinkedIn connection message"><?php echo e(old('linkedin_connection_message')); ?></textarea>
                            <?php $__errorArgs = ['linkedin_connection_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Proposal Information -->
                <div class="dashboard-card">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-primary mb-4 flex items-center">
                            <i class="fas fa-paper-plane mr-2"></i>
                            Proposal & Bidding Details
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div>
                                <label for="upwork_proposal_amount" class="form-label">Proposal Amount ($)</label>
                                <input type="number" name="upwork_proposal_amount" id="upwork_proposal_amount" value="<?php echo e(old('upwork_proposal_amount')); ?>" 
                                    min="0" step="0.01" class="form-input" placeholder="Your bid amount">
                                <?php $__errorArgs = ['upwork_proposal_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_proposal_delivery_days" class="form-label">Delivery Time (days)</label>
                                <input type="number" name="upwork_proposal_delivery_days" id="upwork_proposal_delivery_days" value="<?php echo e(old('upwork_proposal_delivery_days')); ?>" 
                                    min="1" class="form-input" placeholder="Days to complete">
                                <?php $__errorArgs = ['upwork_proposal_delivery_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="upwork_proposal_sent_at" class="form-label">Proposal Sent Date</label>
                                <input type="datetime-local" name="upwork_proposal_sent_at" id="upwork_proposal_sent_at" value="<?php echo e(old('upwork_proposal_sent_at')); ?>" 
                                    class="form-input">
                                <?php $__errorArgs = ['upwork_proposal_sent_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mt-4">
                            <label for="upwork_proposal_text" class="form-label">Proposal Text</label>
                            <textarea name="upwork_proposal_text" id="upwork_proposal_text" rows="6" class="form-input" 
                                placeholder="Your proposal text"><?php echo e(old('upwork_proposal_text')); ?></textarea>
                            <?php $__errorArgs = ['upwork_proposal_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Additional Information -->
                <div class="dashboard-card">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-primary mb-4 flex items-center">
                            <i class="fas fa-info-circle mr-2"></i>
                            Additional Information
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="assigned_to" class="form-label">Assigned To *</label>
                                <select name="assigned_to" id="assigned_to" required class="form-input">
                                    <option value="">Select user</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>" <?php echo e(old('assigned_to') == $user->id ? 'selected' : ''); ?>>
                                            <?php echo e($user->name); ?> (<?php echo e($user->role->display_name ?? 'No Role'); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="project_id" class="form-label">Related Project</label>
                                <select name="project_id" id="project_id" class="form-input">
                                    <option value="">Select project (optional)</option>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>" <?php echo e(old('project_id') == $project->id ? 'selected' : ''); ?>>
                                            <?php echo e($project->name); ?> (<?php echo e(ucfirst(str_replace('_', ' ', $project->status))); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mt-4">
                            <label for="bidding_notes" class="form-label">Bidding Notes</label>
                            <textarea name="bidding_notes" id="bidding_notes" rows="4" class="form-input" 
                                placeholder="Additional notes about this lead"><?php echo e(old('bidding_notes')); ?></textarea>
                            <?php $__errorArgs = ['bidding_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-4 flex items-center">
                            <input type="checkbox" name="requires_connects" id="requires_connects" value="1" 
                                <?php echo e(old('requires_connects') ? 'checked' : ''); ?> class="mr-2">
                            <label for="requires_connects" class="text-sm text-gray-700">This lead requires Upwork connects</label>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-save mr-2"></i>
                        Create Lead
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function togglePlatformFields() {
            const platform = document.getElementById('bidding_platform').value;
            const upworkFields = document.getElementById('upwork-fields');
            const linkedinFields = document.getElementById('linkedin-fields');
            
            // Hide all platform-specific fields
            upworkFields.style.display = 'none';
            linkedinFields.style.display = 'none';
            
            // Show relevant fields based on platform
            if (platform === 'upwork') {
                upworkFields.style.display = 'block';
            } else if (platform === 'linkedin') {
                linkedinFields.style.display = 'block';
            }
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            togglePlatformFields();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/leads/create.blade.php ENDPATH**/ ?>