<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Profit Shares')); ?>

            </h2>
            <?php if(auth()->user()->hasRole('admin')): ?>
                <div class="flex space-x-2">
                    <a href="<?php echo e(route('profit-shares.create')); ?>" class="btn-primary">
                        Create Profit Share
                    </a>
                    <button onclick="openCalculator()" class="btn-secondary">
                        Calculate Shares
                    </button>
                </div>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Profit Calculator Modal (Admin Only) -->
            <?php if(auth()->user()->hasRole('admin')): ?>
            <div id="calculatorModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
                <div class="flex items-center justify-center min-h-screen p-4">
                    <div class="dashboard-card max-w-md w-full">
                        <div class="p-6">
                            <h3 class="text-lg font-semibold text-primary mb-4">Calculate Profit Shares</h3>
                            <form action="<?php echo e(route('profit-shares.calculate')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-4">
                                    <label for="project_id" class="form-label">Select Project</label>
                                    <select name="project_id" id="project_id" required class="form-input">
                                        <option value="">Choose a completed project</option>
                                        <?php $__currentLoopData = \App\Models\Project::where('status', 'completed')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label for="total_profit" class="form-label">Total Profit ($)</label>
                                    <input type="number" name="total_profit" id="total_profit" required 
                                        min="0" step="0.01" class="form-input" placeholder="Enter total profit">
                                </div>
                                <div class="flex justify-end space-x-2">
                                    <button type="button" onclick="closeCalculator()" class="btn-secondary">
                                        Cancel
                                    </button>
                                    <button type="submit" class="btn-primary">
                                        Calculate & Create
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="dashboard-card">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-primary">
                            <?php if(auth()->user()->hasRole('admin')): ?>
                                All Profit Shares
                            <?php else: ?>
                                My Profit Shares
                            <?php endif; ?>
                        </h3>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success mb-4">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-container">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="table-header">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Project</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">User</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Percentage</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Amount</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Calculated Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Paid Date</th>
                                    <?php if(auth()->user()->hasRole('admin')): ?>
                                    <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Actions</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $profitShares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profitShare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="table-row">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-primary"><?php echo e($profitShare->project->name); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-secondary"><?php echo e($profitShare->user->name); ?></div>
                                        <div class="text-xs text-muted"><?php echo e($profitShare->user->role ? $profitShare->user->role->display_name : 'No Role'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                        <?php echo e(number_format($profitShare->percentage, 2)); ?>%
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-primary">
                                        $<?php echo e(number_format($profitShare->amount, 2)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="status-badge status-<?php echo e($profitShare->status); ?>">
                                            <?php echo e(ucfirst($profitShare->status)); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                        <?php echo e($profitShare->calculated_date->format('M d, Y')); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-secondary">
                                        <?php echo e($profitShare->paid_date ? $profitShare->paid_date->format('M d, Y') : 'Not Paid'); ?>

                                    </td>
                                    <?php if(auth()->user()->hasRole('admin')): ?>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex space-x-2">
                                            <a href="<?php echo e(route('profit-shares.show', $profitShare)); ?>" class="text-blue-600 hover:text-blue-900">View</a>
                                            <a href="<?php echo e(route('profit-shares.edit', $profitShare)); ?>" class="text-green-600 hover:text-green-900">Edit</a>
                                            <form action="<?php echo e(route('profit-shares.destroy', $profitShare)); ?>" method="POST" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="<?php echo e(auth()->user()->hasRole('admin') ? '8' : '7'); ?>" class="px-6 py-4 text-center text-sm text-secondary">No profit shares found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($profitShares->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openCalculator() {
            document.getElementById('calculatorModal').classList.remove('hidden');
        }

        function closeCalculator() {
            document.getElementById('calculatorModal').classList.add('hidden');
        }

        // Close modal when clicking outside
        document.getElementById('calculatorModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeCalculator();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/profit-shares/index.blade.php ENDPATH**/ ?>