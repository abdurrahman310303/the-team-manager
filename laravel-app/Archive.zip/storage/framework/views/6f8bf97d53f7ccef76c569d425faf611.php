<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-primary leading-tight">
                <?php echo e(__('Projects')); ?>

            </h2>
            <?php if(auth()->user()->hasRole('admin')): ?>
                <a href="<?php echo e(route('projects.create')); ?>" class="btn-primary">
                    Create New Project
                </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="background-color: var(--light-gray); min-height: 100vh;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="dashboard-card">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-primary">All Projects</h3>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success mb-4">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-container">
                        <table class="w-full divide-y divide-gray-200">
                            <thead class="table-header">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider w-1/4">Name</th>
                                    <th class="px-4 py-3 text-center text-xs font-medium uppercase tracking-wider w-16">Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden md:table-cell w-1/6">Budget</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden lg:table-cell w-1/6">Manager</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden lg:table-cell w-1/6">Start Date</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden lg:table-cell w-1/6">End Date</th>
                                    <th class="px-4 py-3 text-center text-xs font-medium uppercase tracking-wider w-24">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="table-row hover:bg-gray-50">
                                    <td class="px-4 py-4 text-sm font-medium text-primary">
                                        <div class="flex flex-col">
                                            <span class="font-semibold"><?php echo e($project->name); ?></span>
                                            <span class="text-xs text-gray-500 md:hidden">$<?php echo e(number_format($project->budget, 2)); ?></span>
                                            <span class="text-xs text-gray-500 lg:hidden"><?php echo e($project->projectManager->name); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-4 py-4 text-center">
                                        <span class="status-badge status-<?php echo e(str_replace('_', '-', $project->status)); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $project->status))); ?>

                                        </span>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden md:table-cell">
                                        <span class="font-semibold text-green-600">$<?php echo e(number_format($project->budget, 2)); ?></span>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden lg:table-cell">
                                        <?php echo e($project->projectManager->name); ?>

                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden lg:table-cell">
                                        <span class="text-xs"><?php echo e($project->start_date ? $project->start_date->format('M d, Y') : 'N/A'); ?></span>
                                    </td>
                                    <td class="px-4 py-4 text-sm text-secondary hidden lg:table-cell">
                                        <span class="text-xs"><?php echo e($project->end_date ? $project->end_date->format('M d, Y') : 'N/A'); ?></span>
                                    </td>
                                    <td class="px-4 py-4 text-center">
                                        <div class="flex flex-col gap-1">
                                            <a href="<?php echo e(route('projects.show', $project)); ?>" class="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded hover:bg-blue-200 text-center transition-colors">View</a>
                                            <?php if(auth()->user()->hasRole('admin')): ?>
                                                <a href="<?php echo e(route('projects.edit', $project)); ?>" class="inline-block px-2 py-1 text-xs bg-green-100 text-green-800 rounded hover:bg-green-200 text-center transition-colors">Edit</a>
                                                <form action="<?php echo e(route('projects.destroy', $project)); ?>" method="POST" class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="w-full px-2 py-1 text-xs bg-red-100 text-red-800 rounded hover:bg-red-200 transition-colors" onclick="return confirm('Are you sure?')">Delete</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-4 text-center text-sm text-secondary">No projects found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($projects->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/apple/Documents/the-team-manager/laravel-app/resources/views/projects/index.blade.php ENDPATH**/ ?>